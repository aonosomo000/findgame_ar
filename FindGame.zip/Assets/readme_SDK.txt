Vuforia Augmented Reality SDK Release Package
==============================================

Vuforia supports Unity 4.6.4 or newer.
To learn more about Vuforia, go to https://developer.vuforia.com/library/getting-started
To view the SDK license agreement, go to https://developer.vuforia.com/legal/vuforia-developer-agreement
To view the release notes, go to https://developer.vuforia.com/library/release-notes

/*============================================================================
Copyright (c) 2015 PTC Inc.
All Rights Reserved.
Confidential and Proprietary - PTC Inc.
  ============================================================================*/
