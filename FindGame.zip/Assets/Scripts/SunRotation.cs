﻿using UnityEngine;
using System.Collections;

public class SunRotation : MonoBehaviour {

    public float Rotate_x;
    public float Rotate_y;
    public float Rotate_z;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(new Vector3(Rotate_x, Rotate_y, Rotate_z) * Time.deltaTime);
	}
}
