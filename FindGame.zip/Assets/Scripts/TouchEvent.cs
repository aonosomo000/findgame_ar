﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TouchEvent: MonoBehaviour {

	public GameObject Hidden_1;
    public GameObject Hidden_2;
    public GameObject Hidden_3;
    public GameObject Hidden_4;
    public GameObject Hidden_5;
    public GameObject Hidden_6;
    public GameObject Hidden_7;
    public GameObject Hidden_8;
    public GameObject Hidden_9;
    public GameObject Hidden_10;
    public GameObject Hidden_11;
    public GameObject Hidden_12;
    public GameObject Hidden_13;
    public GameObject Hidden_14;
    public GameObject Hidden_15;
    public GameObject Hidden_16;

    public GameObject Prevent_Cube_1;
    public GameObject Prevent_Cube_2;
    public GameObject Prevent_Cube_3;
    public GameObject Prevent_Cube_4;

    public GameObject Level1;
    public GameObject Level2;
    public GameObject Level3;
    public GameObject Level4;
    
    public GameObject UI_AR;
    public GameObject Tutorial_UI;

    public Text Count_Text;
    public GameObject Continue;
    public GameObject Pause;
    public GameObject Back;
    public GameObject Warning;
    public GameObject Complite_Text;
    public GameObject Final_Text;

    private int count1, count2, count3, count4;
    private int complite_check;

    void Start()
    {
        CountCheck();
        complite_check = 0;
        count1 = 0;
        count2 = 0;
        count3 = 0;
        count4 = 0;
    }

	void Update()
	{
		if(Input.touchCount > 0)
		{
			Vector2 pos = Input.GetTouch(0).position;    // 터치한 위치
			Vector3 theTouch = new Vector3(pos.x, pos.y, 0.0f);    // 변환 안하고 바로 Vector3로 받기
			
			
			Ray ray = Camera.main.ScreenPointToRay(theTouch);    // 터치한 좌표 레이로 바꾸기
			RaycastHit hit;    // 정보 저장할 구조체 만들기
			if(Physics.Raycast(ray, out hit, 1000000))    // 레이저를 끝까지 쏘자. 충돌 한 것이 있으면 return true
			{
				if(Input.GetTouch(0).phase == TouchPhase.Began)    // 딱 처음 터치 할때 발생한다
				{
                    if (hit.transform.name.Equals("Complite_text"))
                        Complite_Text.SetActive(false);
                    if (hit.transform.name.Equals("Warning"))
                        Warning.SetActive(false);
                    if (hit.transform.name.Equals("Prevent_Cube_1"))
                    {
                        CountCheck();
                        if (complite_check == 0)
                        {
                            Prevent_Cube_1.SetActive(false);
                            Level1.SetActive(true);
                        }
                        
                    }
                    if (hit.transform.name.Equals("Prevent_Cube_2"))
                    {
                        CountCheck();
                        if (complite_check == 1)
                        {
                            Prevent_Cube_2.SetActive(false);
                            Level2.SetActive(true);
                        }
                        else
                        {
                            Warning.SetActive(true);
                        }
                    }
                    if (hit.transform.name.Equals("Prevent_Cube_3"))
                    {
                        CountCheck();
                        if (complite_check == 2)
                        {
                            Prevent_Cube_3.SetActive(false);
                            Level3.SetActive(true);
                        }
                        else
                        {
                            Warning.SetActive(true);
                        }
                    }
                    if (hit.transform.name.Equals("Prevent_Cube_4"))
                    {
                        CountCheck();
                        if (complite_check == 3)
                        {
                            Prevent_Cube_4.SetActive(false);
                            Level4.SetActive(true);
                        }
                        else
                        {
                            Warning.SetActive(true);
                        }
                    }

                    if (hit.transform.tag.Equals("Hidden_1")) //레벨 1
                    {
                        Hidden_1.SetActive(false);
                        count1 += 1;
                        if (count1 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_2"))
                    {
                        Hidden_2.SetActive(false);
                        count1 += 1;
                        if (count1 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_3"))
                    {
                        Hidden_3.SetActive(false);
                        count1 += 1;
                        if (count1 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_4"))
                    {
                        Hidden_4.SetActive(false);
                        count1 += 1;
                        if (count1 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_5")) //레벨 2
                    {
                        Hidden_5.SetActive(false);
                        count2 += 1;
                        if (count2 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_6"))
                    {
                        Hidden_6.SetActive(false);
                        count2 += 1;
                        if (count2 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_7"))
                    {
                        Hidden_7.SetActive(false);
                        count2 += 1;
                        if (count2 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_8"))
                    {
                        Hidden_8.SetActive(false);
                        count2 += 1;
                        if (count2 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_9")) //레벨 3
                    {
                        Hidden_9.SetActive(false);
                        count3 += 1;
                        if (count3 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_10"))
                    {
                        Hidden_10.SetActive(false);
                        count3 += 1;
                        if (count3 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_11"))
                    {
                        Hidden_11.SetActive(false);
                        count3 += 1;
                        if (count3 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_12"))
                    {
                        Hidden_12.SetActive(false);
                        count3 += 1;
                        if (count3 == 4)
                        {
                            complite_check += 1;
                            Complite_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_13")) //레벨 4
                    {
                        Hidden_13.SetActive(false);
                        count4 += 1;
                        if (count4 == 4)
                        {
                            complite_check += 1;
                            Final_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_14"))
                    {
                        Hidden_14.SetActive(false);
                        count4 += 1;
                        if (count4 == 4)
                        {
                            complite_check += 1;
                            Final_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_15"))
                    {
                        Hidden_15.SetActive(false);
                        count4 += 1;
                        if (count4 == 4)
                        {
                            complite_check += 1;
                            Final_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Hidden_16"))
                    {
                        Hidden_16.SetActive(false);
                        count4 += 1;
                        if (count4 == 4)
                        {
                            complite_check += 1;
                            Final_Text.SetActive(true);
                        }
                    }
                    if (hit.transform.tag.Equals("Start")) //게임시작 터치 시 UI 제거
                        UI_AR.SetActive(false);
                    if (hit.transform.name.Equals("Tutorial")) //도움말 터치 시
                    {
                        UI_AR.SetActive(false);
                        Tutorial_UI.SetActive(true);
                    }
                    if (hit.transform.name.Equals("Back")) //이전으로
                    {
                        UI_AR.SetActive(true);
                        Tutorial_UI.SetActive(false);
                    }
                        
				}
				else if(Input.GetTouch(0).phase == TouchPhase.Moved)    // 터치하고 움직이면 발생한다.
				{
					
				}
				else if(Input.GetTouch(0).phase == TouchPhase.Ended)    // 터치 따악 떼면 발생한다.
				{
					
				}
			}
		}
	}
    void CountCheck()
    {
        Warning.SetActive(false);

        if(complite_check == 0)
            Count_Text.text = "찾은 갯수 (" + count1 + "/4)";
        if (complite_check == 1)
            Count_Text.text = "찾은 갯수 (" + count2 + "/4)";
        if (complite_check == 2)
            Count_Text.text = "찾은 갯수 (" + count3 + "/4)";
        if (complite_check == 3)
            Count_Text.text = "찾은 갯수 (" + count4 + "/4)";

    }
}